iverilog -g2005-sv -o Neuromorphic_design_tb.vvp Neuromorphic_design.sv tb.sv
vvp Neuromorphic_design_tb.vvp
gtkwave Neuromorphic_design.vcd